const Koa = require('koa');
const bodyParser = require('koa-bodyparser');
const fs = require('fs');
const path = require('path');

const app = new Koa();
app.use(bodyParser());

app.use(async (ctx) => {
    if (ctx.method === 'GET' && ctx.path === '/login') {
        ctx.type = 'html';
        ctx.body = fs.createReadStream(path.join(__dirname, 'login.html'));
    } else if (ctx.method === 'POST' && ctx.path === '/login') {
        const { username, password } = ctx.request.body;
        if (!username || !password) {
            ctx.status = 400;
            ctx.body = 'Nieprawidłowa nazwa użytkownika lub hasło';
        } else if (password.length < 8) {
            ctx.status = 400;
            ctx.body = 'To hasło jest zbyt krótkie';
        } else if (username === 'admin' && password === 'adminadmin') {
            ctx.body = 'Zalogowany!';
        } else {
            ctx.body = 'Nieprawidłowa nazwa użytkownika lub hasło';
        }
    } else if (ctx.method === 'DELETE' && ctx.path === '/login') {
        ctx.body = 'Odebrałem polecenie usuń';
    } else if (ctx.method === 'PUT' && ctx.path === '/login') {
        ctx.body = 'Odebrałem polecenie zaktualizuj';
    } else if (ctx.method === 'PATCH' && ctx.path === '/login') {
        ctx.body = 'Odebrałem polecenie popraw';
    } else {
        ctx.status = 404;
    }
});

app.listen(3000, () => {
    console.log('Serwer uruchomiony na porcie 3000');
});

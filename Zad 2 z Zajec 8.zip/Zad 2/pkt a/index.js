const xlsx = require('xlsx');
const fs = require('fs');
const path = require('path');

// plik Excel
const workbook = xlsx.readFile('drogi-rowerowe-gus.xlsx');
const sheet_name_list = workbook.SheetNames;
const data = xlsx.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);

// do JSON
fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
console.log('Data has been converted to JSON and saved to data.json');


const http = require('http');
const server = http.createServer((req, res) => {
    const filePath = path.join(__dirname, req.url === '/' ? 'index.html' : req.url);
    fs.readFile(filePath, (err, content) => {
        if (err) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.write('Not Found');
            res.end();
        } else {
            res.writeHead(200, { 'Content-Type': path.extname(filePath) === '.html' ? 'text/html' : 'application/json' });
            res.write(content);
            res.end();
        }
    });
});

server.listen(8080, () => {
    console.log('Server is listening on port 8080');
});

document.addEventListener('DOMContentLoaded', () => {
    const locationName = document.getElementById('location-name');
    const temperatureValue = document.getElementById('temperature-value');
    const windSpeedValue = document.getElementById('wind-speed-value');
    const message = document.getElementById('message');
    const forecastMessage = document.getElementById('forecast-message');

    const fetchWeatherData = async (latitude, longitude) => {
        try {
            console.log(`Fetching weather data for latitude: ${latitude}, longitude: ${longitude}`);
            const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&daily=precipitation_sum&timezone=Europe/Warsaw`);
            const data = await response.json();
            console.log('Weather data:', data);

            const currentWeather = data.current_weather;
            const forecast = data.daily;

            locationName.textContent = `Poznań`;
            temperatureValue.textContent = currentWeather.temperature;
            windSpeedValue.textContent = currentWeather.windspeed;

            let tempMessage = '';
            if (currentWeather.temperature < 10) {
                tempMessage = 'Zimno';
            } else if (currentWeather.temperature < 25) {
                tempMessage = 'Przyjemnie';
            } else {
                tempMessage = 'Upał';
            }
            message.textContent = tempMessage;

            const precipitation = forecast.precipitation_sum[1];
            if (precipitation > 0) {
                forecastMessage.textContent = 'Prognoza na jutro: spodziewane opady, pamiętaj o wzięciu parasola.';
            } else {
                forecastMessage.textContent = 'Prognoza na jutro: brak opadów, zachęcamy do wyjścia na spacer.';
            }
        } catch (error) {
            console.error('Error fetching weather data:', error);
        }
    };

    // okalizacja
    const latitude = 52.4064;
    const longitude = 16.9252;

    fetchWeatherData(latitude, longitude);
});

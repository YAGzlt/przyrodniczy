import { expect } from 'chai';

describe('Sample Tests', () => {
    it('should pass a basic assertion', () => {
        expect(true).to.be.true;
    });

    it('should add two numbers correctly', () => {
        const result = 1 + 2;
        expect(result).to.equal(3);
    });

    it('should concatenate strings', () => {
        const greeting = 'Hello';
        const name = 'World';
        const message = `${greeting}, ${name}!`;
        expect(message).to.equal('Hello, World!');
    });
});

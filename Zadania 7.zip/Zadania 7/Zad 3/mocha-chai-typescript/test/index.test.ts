import { expect } from 'chai';
import { add, multiply } from '../src/index';

describe('Math Functions', () => {
    it('should add two numbers', () => {
        expect(add(2, 3)).to.equal(5);
    });

    it('should multiply two numbers', () => {
        expect(multiply(2, 3)).to.equal(6);
    });
});

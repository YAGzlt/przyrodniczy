// test/test.mjs
import { expect } from 'chai';

// Przykładowa funkcja do przetestowania
function add(a, b) {
  return a + b;
}

// Testy
describe('Add Function', () => {
  it('should return 4 for 2 + 2', () => {
    expect(add(2, 2)).to.equal(4);
  });

  it('should return 0 for -2 + 2', () => {
    expect(add(-2, 2)).to.equal(0);
  });
});

// Moja pierwsza funkcja
function multiply(a, b) {
  return a * b;
}

// Testy dla mojej pierwszej funkcji
describe('Multiply Function', () => {
  it('should return 6 for 2 * 3', () => {
    expect(multiply(2, 3)).to.equal(6);
  });

  it('should return -6 for -2 * 3', () => {
    expect(multiply(-2, 3)).to.equal(-6);
  });
});

// Moja druga funkcja
function reverseString(str) {
  return str.split('').reverse().join('');
}

// Testy dla mojej drugiej funkcji
describe('Reverse String Function', () => {
  it('should return "olleh" for "hello"', () => {
    expect(reverseString('hello')).to.equal('olleh');
  });

  it('should return "dlrow" for "world"', () => {
    expect(reverseString('world')).to.equal('dlrow');
  });
});

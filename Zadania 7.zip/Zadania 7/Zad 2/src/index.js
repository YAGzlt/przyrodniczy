"use strict";
// Przykładowy string
let greeting = "Hello, world";
// Przykładowa tablica
let numbers = [1, 2, 3, 4, 5];
let person = {
    name: "John Doe",
    age: 30
};
let product = {
    id: 1,
    name: "Laptop",
    price: 999.99
};
// Przykładowe funkcje
function formatStringWithNumber(str, num) {
    return `${str} - ${num}`;
}
function concatenateArrayStrings(arr) {
    return arr.join(", ");
}
// Testowanie funkcji
console.log(formatStringWithNumber(greeting, numbers[0])); // Output: "Hello, world - 1"
console.log(concatenateArrayStrings(["apple", "banana", "cherry"])); // Output: "apple, banana, cherry"

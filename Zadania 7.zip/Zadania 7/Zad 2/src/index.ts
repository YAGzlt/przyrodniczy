// Przykładowy string
let greeting: string = "Hello, world";

// Przykładowa tablica
let numbers: number[] = [1, 2, 3, 4, 5];

// Przykładowe obiekty
interface Person {
  name: string;
  age: number;
}

interface Product {
  id: number;
  name: string;
  price: number;
}

let person: Person = {
  name: "John White",
  age: 25
};

let product: Product = {
  id: 1,
  name: "PC",
  price: 999.99
};

// Przykładowe funkcje
function formatStringWithNumber(str: string, num: number): string {
  return `${str} - ${num}`;
}

function concatenateArrayStrings(arr: string[]): string {
  return arr.join(", ");
}

// Testowanie funkcji
console.log(formatStringWithNumber(greeting, numbers[0])); // Output: "Hello, world - 1"
console.log(concatenateArrayStrings(["pineapple", "banana", "cherry"])); // Output: "pineapple, banana, cherry"

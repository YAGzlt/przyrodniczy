const { MongoClient } = require('mongodb');

const uri = 'mongodb://localhost:27017';
const dbName = 'mydatabase';
const collectionName = 'mycollection';

async function connectToMongoDB() {
    const client = new MongoClient(uri);

    try {
        await client.connect();
        console.log('Connected to MongoDB');

        const db = client.db(dbName);

        await findDocuments(db);
        await insertDocument(db);
        await updateDocument(db);
        await deleteDocument(db);
        await countDocuments(db);
        await retrieveDistinctValues(db);

    } catch (error) {
        console.error('Error:', error);
    } finally {
        await client.close();
        console.log('Disconnected from MongoDB');
    }
}

async function findDocuments(db) {
    const collection = db.collection(collectionName);

    const result = await collection.find({}).toArray();
    console.log('Find Documents:', result);
}

async function insertDocument(db) {
    const collection = db.collection(collectionName);

    const result = await collection.insertOne({ name: 'John', age: 30 });
    console.log('Inserted Document:', result.ops[0]);
}

async function updateDocument(db) {
    const collection = db.collection(collectionName);

    const result = await collection.updateOne({ name: 'John' }, { $set: { age: 40 } });
    console.log('Updated Document:', result.modifiedCount);
}

async function deleteDocument(db) {
    const collection = db.collection(collectionName);

    const result = await collection.deleteOne({ name: 'John' });
    console.log('Deleted Document:', result.deletedCount);
}

async function countDocuments(db) {
    const collection = db.collection(collectionName);

    const count = await collection.countDocuments();
    console.log('Number of Documents:', count);
}

async function retrieveDistinctValues(db) {
    const collection = db.collection(collectionName);

    const distinctValues = await collection.distinct('name');
    console.log('Distinct Values of Field "name":', distinctValues);
}

connectToMongoDB();

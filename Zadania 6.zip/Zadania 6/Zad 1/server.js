const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const crypto = require('crypto');
const path = require('path');
const User = require('./models/User');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect('mongodb://localhost:27017/login-app');

const generateHash = (password, salt) => {
    return new Promise((resolve, reject) => {
        crypto.pbkdf2(password, salt, 10000, 64, 'sha512', (err, derivedKey) => {
            if (err) reject(err);
            resolve(derivedKey.toString('hex'));
        });
    });
};

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password || password.length < 8) {
        return res.status(400).send('Invalid input');
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = await generateHash(password, salt);

    const newUser = new User({ username, passwordHash, salt });
    try {
        await newUser.save();
        res.status(201).send('User registered');
    } catch (err) {
        res.status(500).send('Error registering user');
    }
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).send('Invalid input');
    }

    const user = await User.findOne({ username });
    if (!user) {
        return res.status(400).send('Invalid username or password');
    }

    const passwordHash = await generateHash(password, user.salt);
    if (passwordHash !== user.passwordHash) {
        return res.status(400).send('Invalid username or password');
    }

    res.status(200).send('Login successful');
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Book = require('./models/Book');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/login-app', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

app.get('/count', async (req, res) => {
    const count = await Book.countDocuments();
    res.send(`Number of books: ${count}`);
});

app.get('/books', async (req, res) => {
    const books = await Book.find();
    res.json(books);
});

app.get('/books/pages-over/:pages', async (req, res) => {
    const minPages = parseInt(req.params.pages, 10);
    const books = await Book.find({ pages: { $gt: minPages } });
    res.json(books);
});

app.get('/books/genre/:genre', async (req, res) => {
    const genre = req.params.genre;
    const books = await Book.find({ genre });
    res.json(books);
});

app.get('/books/author/:author', async (req, res) => {
    const author = req.params.author;
    const books = await Book.find({ author: new RegExp(author, 'i') });
    res.json(books);
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

const mongoose = require('mongoose');
const faker = require('@faker-js/faker');
const Book = require('../models/Book');

const populateDatabase = async () => {
    await mongoose.connect('mongodb://localhost:27017/login-app', {
        useNewUrlParser: true,
        useUnifiedTopology: true
    });

    console.time("Populate Database");

    const books = [];
    for (let i = 0; i < 1000; i++) {
        books.push({
            title: faker.faker.lorem.words(3),
            author: faker.faker.name.findName(),
            genre: faker.faker.music.genre(),
            pages: faker.faker.datatype.number({ min: 100, max: 1000 }),
            publishedDate: faker.faker.date.past(),
            isbn: faker.faker.datatype.uuid()
        });
    }

    await Book.insertMany(books);

    console.timeEnd("Populate Database");
    mongoose.connection.close();
};

populateDatabase().catch(console.error);
